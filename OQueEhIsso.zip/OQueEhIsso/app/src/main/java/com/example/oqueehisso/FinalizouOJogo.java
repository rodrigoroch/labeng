package com.example.oqueehisso;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FinalizouOJogo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalizou_o_jogo);
    }
}
